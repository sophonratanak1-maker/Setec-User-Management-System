import { Users, CheckCircle, UserX } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface User {
  id: number
  name: string
  email: string
  phone: string
  role: string
  active: boolean
}

interface StatsCardsProps {
  users: User[]
}

export default function StatsCards({ users }: StatsCardsProps) {
  const activeCount = users.filter((user) => user.active).length
  const inactiveCount = users.filter((user) => !user.active).length

  const stats = [
    {
      label: "Total Users",
      value: users.length,
      icon: Users,
      color: "bg-blue-500",
    },
    {
      label: "Active Users",
      value: activeCount,
      icon: CheckCircle,
      color: "bg-green-500",
    },
    {
      label: "Inactive",
      value: inactiveCount,
      icon: UserX,
      color: "bg-red-500",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto">
      {stats.map((stat, index) => {
        const Icon = stat.icon
        return (
          <Card
            key={index}
            className="border border-border overflow-hidden card-hover animate-slide-up"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
                  <p className="text-3xl font-bold text-foreground mt-2">{stat.value}</p>
                </div>
                <div className={`${stat.color} p-3 rounded-lg transition-all duration-300 group hover:rotate-6`}>
                  <Icon className="w-6 h-6 text-white transition-transform duration-300" />
                </div>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
