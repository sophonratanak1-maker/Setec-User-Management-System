import Image from "next/image"

export default function ProfileHeader() {
  return (
    <div className="flex items-center gap-3 animate-slide-down">
      <div className="text-right">
        <p className="text-sm font-semibold text-foreground">Sophon Ratanak</p>
        <p className="text-xs text-muted-foreground">Administrator</p>
      </div>
      <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-primary shadow-md">
        <Image
          src="/profile-avatar.png"
          alt="Sophon Ratanak"
          width={40}
          height={40}
          className="w-full h-full object-cover"
        />
      </div>
    </div>
  )
}
