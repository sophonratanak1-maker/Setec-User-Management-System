"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Edit2, Trash2 } from "lucide-react"

interface User {
  id: number
  name: string
  email: string
  phone: string
  address: string
  role: string
  active: boolean
}

interface UsersTableProps {
  users: User[]
  onEditUser: (user: User) => void
  onDeleteUser: (id: number) => void
  isAdmin?: boolean
}

export default function UsersTable({ users, onEditUser, onDeleteUser, isAdmin = true }: UsersTableProps) {
  return (
    <Card className="border border-border card-hover">
      <CardHeader className="animate-slide-down pb-4">
        <CardTitle className="text-2xl">Users Overview</CardTitle>
        <CardDescription>Manage and view all registered users</CardDescription>
      </CardHeader>
      <CardContent>
        {users.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <p>No users found</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-800 text-white">
                  <th className="px-6 py-3 text-center text-sm font-semibold">#</th>
                  <th className="px-6 py-3 text-center text-sm font-semibold">Name</th>
                  <th className="px-6 py-3 text-center text-sm font-semibold">Email</th>
                  <th className="px-6 py-3 text-center text-sm font-semibold">Phone</th>
                  <th className="px-6 py-3 text-center text-sm font-semibold">Address</th>
                  <th className="px-6 py-3 text-center text-sm font-semibold">Role</th>
                  <th className="px-6 py-3 text-center text-sm font-semibold">Active</th>
                  <th className="px-6 py-3 text-center text-sm font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user, index) => (
                  <tr
                    key={user.id}
                    className="border-b border-border hover:bg-gray-50 transition-colors animate-slide-down"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <td className="px-6 py-4 text-sm font-medium text-foreground text-center">{index + 1}</td>
                    <td className="px-6 py-4 text-sm text-foreground text-center">{user.name}</td>
                    <td className="px-6 py-4 text-sm text-muted-foreground text-center">{user.email}</td>
                    <td className="px-6 py-4 text-sm text-muted-foreground text-center">{user.phone}</td>
                    <td className="px-6 py-4 text-sm text-muted-foreground text-center">{user.address}</td>
                    <td className="px-6 py-4 text-sm text-center">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold inline-block ${
                          user.role === "Admin"
                            ? "bg-blue-100 text-blue-700"
                            : user.role === "Manager"
                              ? "bg-purple-100 text-purple-700"
                              : "bg-gray-100 text-gray-700"
                        }`}
                      >
                        {user.role}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-center">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold inline-block ${
                          user.active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                        }`}
                      >
                        {user.active ? "✓ Active" : "✗ Inactive"}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-sm flex gap-1 justify-center items-center">
                      <Button
                        size="sm"
                        className="bg-yellow-500 hover:bg-yellow-600 text-white btn-animate px-2 py-1 h-auto"
                        onClick={() => onEditUser(user)}
                        title="Edit user"
                        disabled={!isAdmin}
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        className="btn-animate px-2 py-1 h-auto"
                        onClick={() => onDeleteUser(user.id)}
                        title="Delete user"
                        disabled={!isAdmin}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
