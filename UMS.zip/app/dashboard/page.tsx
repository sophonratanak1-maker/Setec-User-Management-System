"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Sidebar from "@/components/sidebar"
import StatsCards from "@/components/stats-cards"
import UsersTable from "@/components/users-table"
import ProfileHeader from "@/components/profile-header"
import { Users, AlertCircle, Mail, Phone } from "lucide-react"

// 🔗 Backend API URL (your Node + Mongoose server)
const API_URL = "http://localhost:9000/api/user"

interface User {
  id: number          // local numeric id for table
  backendId?: string  // MongoDB _id from backend
  name: string
  email: string
  phone: string
  address: string
  role: string
  active: boolean
}

export default function Home() {
  const router = useRouter()
  const [isAuthChecked, setIsAuthChecked] = useState(false)
  const [currentRole, setCurrentRole] = useState<string>("User")

  useEffect(() => {
    if (typeof window === "undefined") return

    const stored = localStorage.getItem("ums_auth_user")
    if (!stored) {
      router.push("/")
      return
    }

    try {
      const parsed = JSON.parse(stored)
      if (parsed.role) {
        setCurrentRole(parsed.role)
      }
    } catch (err) {
      console.error("Error parsing auth user from localStorage:", err)
    }

    setIsAuthChecked(true)
  }, [router])



  const [users, setUsers] = useState<User[]>([
    {
      id: 1,
      name: "Alice Johnson",
      email: "alice@example.com",
      phone: "+1 (555) 123-4567",
      address: "123 Main St, New York, NY",
      role: "Admin",
      active: true,
    },
    {
      id: 2,
      name: "Bob Smith",
      email: "bob@example.com",
      phone: "+1 (555) 234-5678",
      address: "456 Oak Ave, Los Angeles, CA",
      role: "Manager",
      active: true,
    },
    {
      id: 3,
      name: "Carol White",
      email: "carol@example.com",
      phone: "+1 (555) 345-6789",
      address: "789 Pine Rd, Chicago, IL",
      role: "User",
      active: false,
    },
  ])

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    role: "User",
    active: true,
  })
  const [editingId, setEditingId] = useState<number | null>(null)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null)
  const [activeSection, setActiveSection] = useState<"dashboard" | "users" | "admin">("dashboard")
  const isAdmin = true


  // 🔹 Helper: load users from backend (GET)
  const fetchUsersFromApi = async () => {
    try {
      const res = await fetch(API_URL)
      const data = await res.json()

      const mapped: User[] = data.map((u: any, index: number) => ({
        id: index + 1, // local numeric index for display
        backendId: u._id,
        name: u.name,
        email: u.email,
        phone: u.phone || "",
        address: u.address || "",
        role: u.role || "User",
        active: u.active ?? true,
      }))

      setUsers(mapped)
    } catch (err) {
      console.error("Error loading users from API:", err)
    }
  }

  // 🔹 Load users from backend when page opens (GET)
  useEffect(() => {
    fetchUsersFromApi()
  }, [])

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {}

    if (!formData.name.trim()) {
      newErrors.name = "Name is required"
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required"
    } else if (!validateEmail(formData.email)) {
      newErrors.email = "Email must be in correct format (e.g., user@example.com)"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
    if (errors[name]) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[name]
        return newErrors
      })
    }
  }

  const handleRoleChange = (value: string) => {
    setFormData((prev) => ({ ...prev, role: value }))
  }

  const handleActiveChange = (value: string) => {
    setFormData((prev) => ({ ...prev, active: value === "Active" }))
  }

  // 🔹 Save user (Create or Update) with backend
  const handleSaveUser = async () => {
    if (!validateForm()) return

    try {
      if (editingId !== null) {
        // UPDATE (PUT)
        const existing = users.find((u) => u.id === editingId)

        if (existing?.backendId) {
          await fetch(`${API_URL}/${existing.backendId}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formData),
          })
        }

        setUsers(users.map((user) => (user.id === editingId ? { ...user, ...formData } : user)))
        setEditingId(null)

        // reload from MongoDB to be 100% sure
        await fetchUsersFromApi()
      } else {
        // CREATE (POST)
        const res = await fetch(API_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
        })
        const json = await res.json()
        const saved = json.data || json

        const newUser: User = {
          id: Math.max(...users.map((u) => u.id), 0) + 1,
          backendId: saved._id,
          ...formData,
        }
        setUsers([...users, newUser])

        // reload from MongoDB to be 100% sure
        await fetchUsersFromApi()
      }

      setFormData({ name: "", email: "", phone: "", address: "", role: "User", active: true })
    } catch (err) {
      console.error("Error saving user to API:", err)
    }
  }

  const handleEditUser = (user: User) => {
    setFormData({
      name: user.name,
      email: user.email,
      phone: user.phone,
      address: user.address,
      role: user.role,
      active: user.active,
    })
    setEditingId(user.id)
  }

  const handleCancel = () => {
    setFormData({ name: "", email: "", phone: "", address: "", role: "User", active: true })
    setEditingId(null)
    setErrors({})
  }

  const handleClear = () => {
    setFormData({ name: "", email: "", phone: "", address: "", role: "User", active: true })
    setErrors({})
  }

  // 🔹 Delete user (with backend)
  const confirmDelete = async () => {
    if (deleteConfirm !== null) {
      try {
        const userToDelete = users.find((u) => u.id === deleteConfirm)
        if (userToDelete?.backendId) {
          await fetch(`${API_URL}/${userToDelete.backendId}`, {
            method: "DELETE",
          })
        }
      } catch (err) {
        console.error("Error deleting user from API:", err)
      }

      setUsers(users.filter((user) => user.id !== deleteConfirm))
      setDeleteConfirm(null)

      // reload from MongoDB to be 100% sure
      await fetchUsersFromApi()
    }
  }

  const handleDeleteUser = (id: number) => {
    setDeleteConfirm(id)
  }



  // Auth guard: if user not logged in, don't show dashboard
  if (!isAuthChecked) {
    return null
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      <main className="flex-1 overflow-auto">
        <div className="p-6 space-y-6 animate-fade-in">
          {activeSection === "dashboard" || activeSection === "admin" ? (
            <>
              <div className="flex items-center justify-center relative animate-slide-down">
                <h1 className="text-3xl font-bold text-foreground">User Management System</h1>
                <div className="absolute right-0">
                  <ProfileHeader />
                </div>
              </div>

              <StatsCards users={users} />

              <Card className="border border-border card-hover animate-scale-in">
                <CardHeader className="animate-slide-down">
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5 icon-animate" />
                    {editingId !== null ? "Edit User" : "Add New User"}
                  </CardTitle>
                  <CardDescription>
                    {editingId !== null
                      ? "Update the user details and click Update to save changes"
                      : "Fill in the details to add a new user to the system"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-4 mb-4">
                    <div className="space-y-2 animate-fade-in" style={{ animationDelay: "100ms" }}>
                      <Label htmlFor="name" className="text-sm font-medium">
                        Full Name <span className="text-destructive">*</span>
                      </Label>
                      <Input
                        id="name"
                        name="name"
                        placeholder="Enter full name"
                        value={formData.name}
                        onChange={handleInputChange}
                        className={`bg-background border-input input-animate ${errors.name ? "border-destructive" : ""}`}
                      />
                      {errors.name && (
                        <p className="text-xs text-destructive flex items-center gap-1 animate-fade-in">
                          <AlertCircle className="w-3 h-3" />
                          {errors.name}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2 animate-fade-in" style={{ animationDelay: "150ms" }}>
                      <Label htmlFor="email" className="text-sm font-medium">
                        Email <span className="text-destructive">*</span>
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="Enter email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className={`bg-background border-input input-animate ${errors.email ? "border-destructive" : ""}`}
                      />
                      {errors.email && (
                        <p className="text-xs text-destructive flex items-center gap-1 animate-fade-in">
                          <AlertCircle className="w-3 h-3" />
                          {errors.email}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2 animate-fade-in" style={{ animationDelay: "200ms" }}>
                      <Label htmlFor="phone" className="text-sm font-medium">
                        Phone
                      </Label>
                      <Input
                        id="phone"
                        name="phone"
                        placeholder="Enter phone number"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="bg-background border-input input-animate"
                      />
                    </div>

                    <div className="space-y-2 animate-fade-in" style={{ animationDelay: "250ms" }}>
                      <Label htmlFor="address" className="text-sm font-medium">
                        Address
                      </Label>
                      <Input
                        id="address"
                        name="address"
                        placeholder="Enter address"
                        value={formData.address}
                        onChange={handleInputChange}
                        className="bg-background border-input input-animate"
                      />
                    </div>

                    <div className="space-y-2 animate-fade-in" style={{ animationDelay: "300ms" }}>
                      <Label htmlFor="role" className="text-sm font-medium">
                        Role
                      </Label>
                      <Select value={formData.role} onValueChange={handleRoleChange}>
                        <SelectTrigger className="bg-background border-input input-animate">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="User">User</SelectItem>
                          <SelectItem value="Manager">Manager</SelectItem>
                          <SelectItem value="Admin">Admin</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2 animate-fade-in" style={{ animationDelay: "350ms" }}>
                      <Label htmlFor="active" className="text-sm font-medium">
                        Status
                      </Label>
                      <Select value={formData.active ? "Active" : "Inactive"} onValueChange={handleActiveChange}>
                        <SelectTrigger className="bg-background border-input input-animate">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Active">Active</SelectItem>
                          <SelectItem value="Inactive">Inactive</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2 animate-fade-in" style={{ animationDelay: "400ms" }}>
                      <Label className="text-sm font-medium">&nbsp;</Label>
                      <div className="flex gap-2 pt-1">
                        <Button
                          onClick={handleSaveUser}
                          className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground btn-animate"
                          disabled={!isAdmin}
                        >
                          {editingId !== null ? "Update" : "Add"}
                        </Button>
                        {!isAdmin && (
                          <p className="text-xs text-muted-foreground mt-1">
                            Only admin can add or update users.
                          </p>
                        )}
                        <Button
                          onClick={editingId !== null ? handleCancel : handleClear}
                          variant="outline"
                          className="flex-1 border-border bg-secondary hover:bg-secondary/80 text-secondary-foreground btn-animate"
                        >
                          {editingId !== null ? "Cancel" : "Clear"}
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <UsersTable users={users} onEditUser={handleEditUser} onDeleteUser={handleDeleteUser} isAdmin={isAdmin} />
            </>
          ) : (
            <>
              <div className="text-center mb-8 animate-slide-down">
                <h1 className="text-3xl font-bold text-foreground">All Users</h1>
              </div>

              <div className="border border-border rounded-lg overflow-hidden card-hover animate-scale-in">
                <table className="w-full">
                  <tbody>
                    {users.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center py-12">
                          <Users className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                          <p className="text-muted-foreground text-lg">No users found. Add users from the Dashboard.</p>
                        </td>
                      </tr>
                    ) : (
                      users.map((user, index) => (
                        <tr
                          key={user.id}
                          className="border-b border-border hover:bg-secondary/30 row-animate animate-fade-in"
                          style={{ animationDelay: `${index * 50}ms` }}
                        >
                          <td className="px-6 py-4 text-sm font-medium text-foreground">{index + 1}</td>
                          <td className="px-6 py-4 text-sm font-medium text-foreground">{user.name}</td>
                          <td className="px-6 py-4 text-sm text-foreground flex items-center gap-2">
                            <Mail className="w-4 h-4 text-muted-foreground icon-animate" />
                            {user.email}
                          </td>
                          <td className="px-6 py-4 text-sm text-foreground flex items-center gap-2">
                            <Phone className="w-4 h-4 text-muted-foreground icon-animate" />
                            {user.phone || "—"}
                          </td>
                          <td className="px-6 py-4 text-sm">
                            <span
                              className={`inline-block px-3 py-1 rounded-full font-semibold text-xs transition-all duration-300 hover:shadow-md ${
                                user.role === "Admin"
                                  ? "bg-blue-100 text-blue-700"
                                  : user.role === "Manager"
                                  ? "bg-purple-100 text-purple-700"
                                  : "bg-gray-100 text-gray-700"
                              }`}
                            >
                              {user.role}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm">
                            <span
                              className={`inline-block px-3 py-1 rounded-full font-semibold text-xs transition-all duration-300 ${
                                user.active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                              }`}
                            >
                              {user.active ? "✓ Active" : "✗ Inactive"}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm flex items-center gap-2">
                            <Button
                              onClick={() => handleEditUser(user)}
                              className="bg-yellow-400 hover:bg-yellow-500 text-black font-semibold btn-animate"
                              disabled={!isAdmin}
                            >
                              Update
                            </Button>
                            <Button
                              onClick={() => handleDeleteUser(user.id)}
                              className="bg-red-500 hover:bg-red-600 text-white font-semibold btn-animate"
                              disabled={!isAdmin}
                            >
                              Delete
                            </Button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {deleteConfirm !== null && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 animate-fade-in">
              <Card className="w-96 border border-border animate-scale-in">
                <CardHeader>
                  <CardTitle>Confirm Delete</CardTitle>
                  <CardDescription>
                    Are you sure you want to delete this user? This action cannot be undone.
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex gap-3">
                  <Button
                    onClick={() => setDeleteConfirm(null)}
                    variant="outline"
                    className="flex-1 border-border bg-secondary hover:bg-secondary/80 text-secondary-foreground btn-animate"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={confirmDelete}
                    className="flex-1 bg-destructive hover:bg-destructive/90 text-destructive-foreground btn-animate"
                  >
                    Delete
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
