"use client"

import { useState } from "react"
import LoginForm from "@/components/login-form"
import SignUpForm from "@/components/sign-up-form"

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true)

  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted p-4">
      <div className="w-full max-w-md">
        <div className="animate-fade-in">
          {isLogin ? (
            <LoginForm onSwitchToSignUp={() => setIsLogin(false)} />
          ) : (
            <SignUpForm onSwitchToLogin={() => setIsLogin(true)} />
          )}
        </div>
      </div>
    </main>
  )
}
