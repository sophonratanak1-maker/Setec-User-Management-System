const express = require("express");
const mongoosee = require("mongoose"); // same style name as your teacher
const cors = require("cors");
const PORT = 9000;
const app = express();

// Welcome route (like teacher example)
app.get("/", (req, res) => {
  res.send("Hello User Management System with Mongoose DB!");
});

// Convert express body to JSON
app.use(express.json());
app.use(cors());

// ====== Open connection MongoDB ======
mongoosee
  .connect("mongodb://localhost:27017/User_Management_System")
  .then(() => console.log("MongoDB connected successfully!"))
  .catch((err) => console.log("MongoDB error:", err.message));

// ====== Create Schema and Model (like Product in example) ======
const userSchema = new mongoosee.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, trim: true },
    password: { type: String, required: false, trim: true },
    phone: { type: String, trim: true },
    address: { type: String, trim: true },
    role: { type: String, default: "User", trim: true },
    active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

const User = mongoosee.model("User", userSchema);

// ====== API NodeJS (GET, POST, PUT, DELETE) ======

// POST: insert new user
app.post("/api/user", async (req, res) => {
  try {
    const { name, email, phone, address, role, active } = req.body;

    const newUser = new User({
      name,
      email,
      phone,
      address,
      role,
      active,
    });

    const savedUser = await newUser.save();

    res.status(200).json({
      message: "User add successfully!",
      data: savedUser,
    });
  } catch (err) {
    res.status(400).json({
      message: "Error when add user!",
      error: err.message,
    });
  }
});

// GET: list all users
app.get("/api/user", async (req, res) => {
  try {
    const users = await User.find().sort({ createdAt: -1 });
    res.status(200).json(users);
  } catch (err) {
    res.status(400).json({
      message: "Error when get user list!",
      error: err.message,
    });
  }
});

// GET: get user by id (optional but good)
app.get("/api/user/:id", async (req, res) => {
  try {
    const getById = await User.findById(req.params.id);
    if (!getById) {
      return res.status(404).json({ message: "User not found!" });
    }
    res.status(200).json(getById);
  } catch (err) {
    res.status(400).json({
      message: "Error when get user by id!",
      error: err.message,
    });
  }
});

// PUT: update user by id
app.put("/api/user/:id", async (req, res) => {
  try {
    const { name, email, phone, address, role, active } = req.body;

    const updatedUser = await User.findByIdAndUpdate(
      req.params.id,
      { name, email, phone, address, role, active },
      { new: true, runValidators: true }
    );

    if (!updatedUser) {
      return res.status(404).json({ message: "User not found!" });
    }

    res.status(200).json({
      message: "User update successfully!",
      data: updatedUser,
    });
  } catch (err) {
    res.status(400).json({
      message: "Error when update user!",
      error: err.message,
    });
  }
});

// DELETE: delete user by id
app.delete("/api/user/:id", async (req, res) => {
  try {
    const deletedUser = await User.findByIdAndDelete(req.params.id);

    if (!deletedUser) {
      return res.status(404).json({ message: "User not found!" });
    }

    res.status(200).json({
      message: `User has id: ${req.params.id} delete success!`,
    });
  } catch (err) {
    res.status(400).json({
      message: "Error when delete user!",
      error: err.message,
    });
  }
});




// ====== AUTH ROUTES (Sign Up & Login) ======

// POST: Sign up (create account)

app.post("/api/auth/signup", async (req, res) => {
  try {
    const { fullName, email, password } = req.body;

    if (!fullName || !email || !password) {
      return res.status(400).json({ message: "Full name, email and password are required" });
    }

    const exist = await User.findOne({ email });
    if (exist) {
      return res.status(400).json({ message: "Email already exists, please login" });
    }

    // First account will be Admin, others will be normal User
    const totalUsers = await User.countDocuments();
    const role = totalUsers === 0 ? "Admin" : "User";

    const newUser = new User({
      name: fullName,
      email,
      password,
      role,
      active: true,
    });

    const saved = await newUser.save();

    res.status(200).json({
      message: "Signup success",
      email: saved.email,
      fullName: saved.name,
      role: saved.role,
    });
  } catch (err) {
    res.status(400).json({
      message: "Error when signup user!",
      error: err.message,
    });
  }
});
// POST: Login (check email + password)
app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" });
    }

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(400).json({ message: "Email not found, please sign up first" });
    }

    if (!user.password) {
      return res.status(400).json({ message: "This account has no password. Please sign up again." });
    }

    if (user.password !== password) {
      return res.status(400).json({ message: "Wrong password, please try again" });
    }

    res.status(200).json({
      message: "Login success",
      email: user.email,
      fullName: user.name,
      role: user.role,
    });
  } catch (err) {
    res.status(400).json({
      message: "Error when login user!",
      error: err.message,
    });
  }
});




// ====== StartUp Server NodeJS ======
app.listen(PORT, () => {
  console.log(`Server is running with: http://localhost:${PORT}`);
});
